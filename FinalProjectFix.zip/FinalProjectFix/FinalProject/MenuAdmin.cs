﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class MenuAdmin : Form
    {
        private Form activeForm;
        public MenuAdmin()
        {
            InitializeComponent();
        }

        private void MenuAdmin_Load(object sender, EventArgs e)
        {

        }

        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.PanelDesktopPanel.Controls.Add(childForm);
            this.PanelDesktopPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;

        }

        private void registKamarButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmMH(), sender);
        }

        private void pemilihanKamarButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmKepas(), sender);
        }

        private void informasiPoinButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmMonitor(), sender);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();

            MessageBox.Show("you've been logged out!");
        }

        private void homeButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Home4(), sender);
        }
    }
}
