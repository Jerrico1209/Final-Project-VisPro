﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class MenuMonitor : Form
    {
        private Form activeForm;

        public MenuMonitor()
        {
            InitializeComponent();
        }

        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.PanelDesktopPanel.Controls.Add(childForm);
            this.PanelDesktopPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;

        }



        private void MenuMonitor_Load(object sender, EventArgs e)
        {

        }

        private void profileButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Poin(), sender);
        }

        private void registKamarButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new seatting(), sender);
        }

        private void pemilihanKamarButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new namamahasiswa(), sender);
        }

        private void homeButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Home4(), sender);
        }

        private void PanelDesktopPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();
            MessageBox.Show("yo've been logged out!");
        }

        private void PanelLogo_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
