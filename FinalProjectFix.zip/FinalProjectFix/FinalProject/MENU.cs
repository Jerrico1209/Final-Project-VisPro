﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class MENU : Form
    {
        public MENU()
        {
            InitializeComponent();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Poin poin = new Poin();
            poin.Show();
            this.Hide();
        }

        private void BtnSeatting_Click_1(object sender, EventArgs e)
        {
            seatting seattingg = new seatting();
            seattingg.Show();
            this.Hide();
        }

        private void BtnHome_Click(object sender, EventArgs e)
        {

        }

        private void BtnDaftar_Click_1(object sender, EventArgs e)
        {
            namamahasiswa namamahasiswaa = new namamahasiswa();
            namamahasiswaa.Show();
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();

            MessageBox.Show("you've been logged out");
        }

        private void MENU_Load(object sender, EventArgs e)
        {

        }
        private void BtnHome_Click_1(object sender, EventArgs e)
        {

        }
    }
}
