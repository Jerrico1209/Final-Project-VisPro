﻿
namespace FinalProject
{
    partial class seatting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TxtSeatting = new System.Windows.Forms.TextBox();
            this.TxtDelete = new System.Windows.Forms.Button();
            this.TxtUpdate = new System.Windows.Forms.Button();
            this.TxtSearch = new System.Windows.Forms.Button();
            this.TxtClear = new System.Windows.Forms.Button();
            this.TxtSave = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.a = new System.Windows.Forms.Label();
            this.TxtNama = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 149);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 22);
            this.label1.TabIndex = 35;
            this.label1.Text = "Seatting";
            // 
            // TxtSeatting
            // 
            this.TxtSeatting.Location = new System.Drawing.Point(158, 144);
            this.TxtSeatting.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtSeatting.Name = "TxtSeatting";
            this.TxtSeatting.Size = new System.Drawing.Size(181, 26);
            this.TxtSeatting.TabIndex = 34;
            // 
            // TxtDelete
            // 
            this.TxtDelete.Location = new System.Drawing.Point(1109, 77);
            this.TxtDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtDelete.Name = "TxtDelete";
            this.TxtDelete.Size = new System.Drawing.Size(97, 55);
            this.TxtDelete.TabIndex = 33;
            this.TxtDelete.Text = "Delete";
            this.TxtDelete.UseVisualStyleBackColor = true;
            this.TxtDelete.Click += new System.EventHandler(this.TxtDelete_Click_1);
            // 
            // TxtUpdate
            // 
            this.TxtUpdate.Location = new System.Drawing.Point(975, 157);
            this.TxtUpdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtUpdate.Name = "TxtUpdate";
            this.TxtUpdate.Size = new System.Drawing.Size(97, 55);
            this.TxtUpdate.TabIndex = 32;
            this.TxtUpdate.Text = "Update";
            this.TxtUpdate.UseVisualStyleBackColor = true;
            this.TxtUpdate.Click += new System.EventHandler(this.TxtUpdate_Click_1);
            // 
            // TxtSearch
            // 
            this.TxtSearch.Location = new System.Drawing.Point(1109, 157);
            this.TxtSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtSearch.Name = "TxtSearch";
            this.TxtSearch.Size = new System.Drawing.Size(97, 55);
            this.TxtSearch.TabIndex = 31;
            this.TxtSearch.Text = "Search";
            this.TxtSearch.UseVisualStyleBackColor = true;
            this.TxtSearch.Click += new System.EventHandler(this.TxtSearch_Click_1);
            // 
            // TxtClear
            // 
            this.TxtClear.Location = new System.Drawing.Point(1109, 243);
            this.TxtClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtClear.Name = "TxtClear";
            this.TxtClear.Size = new System.Drawing.Size(97, 55);
            this.TxtClear.TabIndex = 30;
            this.TxtClear.Text = "Clear";
            this.TxtClear.UseVisualStyleBackColor = true;
            this.TxtClear.Click += new System.EventHandler(this.TxtClear_Click_1);
            // 
            // TxtSave
            // 
            this.TxtSave.Location = new System.Drawing.Point(975, 77);
            this.TxtSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtSave.Name = "TxtSave";
            this.TxtSave.Size = new System.Drawing.Size(97, 55);
            this.TxtSave.TabIndex = 29;
            this.TxtSave.Text = "Save";
            this.TxtSave.UseVisualStyleBackColor = true;
            this.TxtSave.Click += new System.EventHandler(this.TxtSave_Click_1);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(47, 375);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1164, 368);
            this.dataGridView1.TabIndex = 28;
            // 
            // a
            // 
            this.a.AutoSize = true;
            this.a.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.a.Location = new System.Drawing.Point(63, 77);
            this.a.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(92, 22);
            this.a.TabIndex = 27;
            this.a.Text = "Username";
            // 
            // TxtNama
            // 
            this.TxtNama.Location = new System.Drawing.Point(158, 75);
            this.TxtNama.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtNama.Name = "TxtNama";
            this.TxtNama.Size = new System.Drawing.Size(181, 26);
            this.TxtNama.TabIndex = 26;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1109, 784);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 36);
            this.button1.TabIndex = 36;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // seatting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1269, 832);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtSeatting);
            this.Controls.Add(this.TxtDelete);
            this.Controls.Add(this.TxtUpdate);
            this.Controls.Add(this.TxtSearch);
            this.Controls.Add(this.TxtClear);
            this.Controls.Add(this.TxtSave);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.a);
            this.Controls.Add(this.TxtNama);
            this.Name = "seatting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seatting";
            this.Load += new System.EventHandler(this.seatting_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtSeatting;
        private System.Windows.Forms.Button TxtDelete;
        private System.Windows.Forms.Button TxtUpdate;
        private System.Windows.Forms.Button TxtSearch;
        private System.Windows.Forms.Button TxtClear;
        private System.Windows.Forms.Button TxtSave;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label a;
        private System.Windows.Forms.TextBox TxtNama;
        private System.Windows.Forms.Button button1;
    }
}