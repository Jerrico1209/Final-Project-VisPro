﻿
namespace FinalProject
{
    partial class Poin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtDelete = new System.Windows.Forms.Button();
            this.TxtUpdate = new System.Windows.Forms.Button();
            this.TxtSearch = new System.Windows.Forms.Button();
            this.TxtClear = new System.Windows.Forms.Button();
            this.TxtSave = new System.Windows.Forms.Button();
            this.TxtVesper = new System.Windows.Forms.TextBox();
            this.TxtSabbath = new System.Windows.Forms.TextBox();
            this.TxtPA = new System.Windows.Forms.TextBox();
            this.d = new System.Windows.Forms.Label();
            this.e = new System.Windows.Forms.Label();
            this.f = new System.Windows.Forms.Label();
            this.TxtNomorKamar = new System.Windows.Forms.TextBox();
            this.TxtMidweek = new System.Windows.Forms.TextBox();
            this.TxtNama = new System.Windows.Forms.TextBox();
            this.b = new System.Windows.Forms.Label();
            this.c = new System.Windows.Forms.Label();
            this.a = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // TxtDelete
            // 
            this.TxtDelete.Location = new System.Drawing.Point(1073, 67);
            this.TxtDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtDelete.Name = "TxtDelete";
            this.TxtDelete.Size = new System.Drawing.Size(97, 55);
            this.TxtDelete.TabIndex = 36;
            this.TxtDelete.Text = "Delete";
            this.TxtDelete.UseVisualStyleBackColor = true;
            this.TxtDelete.Click += new System.EventHandler(this.TxtDelete_Click_1);
            // 
            // TxtUpdate
            // 
            this.TxtUpdate.Location = new System.Drawing.Point(939, 147);
            this.TxtUpdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtUpdate.Name = "TxtUpdate";
            this.TxtUpdate.Size = new System.Drawing.Size(97, 55);
            this.TxtUpdate.TabIndex = 35;
            this.TxtUpdate.Text = "Update";
            this.TxtUpdate.UseVisualStyleBackColor = true;
            this.TxtUpdate.Click += new System.EventHandler(this.TxtUpdate_Click_1);
            // 
            // TxtSearch
            // 
            this.TxtSearch.Location = new System.Drawing.Point(1073, 147);
            this.TxtSearch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtSearch.Name = "TxtSearch";
            this.TxtSearch.Size = new System.Drawing.Size(97, 55);
            this.TxtSearch.TabIndex = 34;
            this.TxtSearch.Text = "Search";
            this.TxtSearch.UseVisualStyleBackColor = true;
            this.TxtSearch.Click += new System.EventHandler(this.TxtSearch_Click_1);
            // 
            // TxtClear
            // 
            this.TxtClear.Location = new System.Drawing.Point(1073, 233);
            this.TxtClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtClear.Name = "TxtClear";
            this.TxtClear.Size = new System.Drawing.Size(97, 55);
            this.TxtClear.TabIndex = 33;
            this.TxtClear.Text = "Clear";
            this.TxtClear.UseVisualStyleBackColor = true;
            this.TxtClear.Click += new System.EventHandler(this.TxtClear_Click_1);
            // 
            // TxtSave
            // 
            this.TxtSave.Location = new System.Drawing.Point(939, 67);
            this.TxtSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtSave.Name = "TxtSave";
            this.TxtSave.Size = new System.Drawing.Size(97, 55);
            this.TxtSave.TabIndex = 32;
            this.TxtSave.Text = "Save";
            this.TxtSave.UseVisualStyleBackColor = true;
            this.TxtSave.Click += new System.EventHandler(this.TxtSave_Click_1);
            // 
            // TxtVesper
            // 
            this.TxtVesper.Location = new System.Drawing.Point(138, 201);
            this.TxtVesper.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtVesper.Name = "TxtVesper";
            this.TxtVesper.Size = new System.Drawing.Size(148, 26);
            this.TxtVesper.TabIndex = 31;
            // 
            // TxtSabbath
            // 
            this.TxtSabbath.Location = new System.Drawing.Point(138, 247);
            this.TxtSabbath.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtSabbath.Name = "TxtSabbath";
            this.TxtSabbath.Size = new System.Drawing.Size(148, 26);
            this.TxtSabbath.TabIndex = 30;
            // 
            // TxtPA
            // 
            this.TxtPA.Location = new System.Drawing.Point(138, 293);
            this.TxtPA.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtPA.Name = "TxtPA";
            this.TxtPA.Size = new System.Drawing.Size(148, 26);
            this.TxtPA.TabIndex = 29;
            // 
            // d
            // 
            this.d.AutoSize = true;
            this.d.Location = new System.Drawing.Point(21, 216);
            this.d.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(60, 20);
            this.d.TabIndex = 28;
            this.d.Text = "Vesper";
            // 
            // e
            // 
            this.e.AutoSize = true;
            this.e.Location = new System.Drawing.Point(20, 258);
            this.e.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.e.Name = "e";
            this.e.Size = new System.Drawing.Size(70, 20);
            this.e.TabIndex = 27;
            this.e.Text = "Sabbath";
            // 
            // f
            // 
            this.f.AutoSize = true;
            this.f.Location = new System.Drawing.Point(21, 305);
            this.f.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.f.Name = "f";
            this.f.Size = new System.Drawing.Size(30, 20);
            this.f.TabIndex = 26;
            this.f.Text = "PA";
            // 
            // TxtNomorKamar
            // 
            this.TxtNomorKamar.Location = new System.Drawing.Point(138, 108);
            this.TxtNomorKamar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtNomorKamar.Name = "TxtNomorKamar";
            this.TxtNomorKamar.Size = new System.Drawing.Size(148, 26);
            this.TxtNomorKamar.TabIndex = 25;
            // 
            // TxtMidweek
            // 
            this.TxtMidweek.Location = new System.Drawing.Point(138, 161);
            this.TxtMidweek.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtMidweek.Name = "TxtMidweek";
            this.TxtMidweek.Size = new System.Drawing.Size(148, 26);
            this.TxtMidweek.TabIndex = 24;
            // 
            // TxtNama
            // 
            this.TxtNama.Location = new System.Drawing.Point(138, 55);
            this.TxtNama.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtNama.Name = "TxtNama";
            this.TxtNama.Size = new System.Drawing.Size(148, 26);
            this.TxtNama.TabIndex = 23;
            // 
            // b
            // 
            this.b.AutoSize = true;
            this.b.Location = new System.Drawing.Point(20, 119);
            this.b.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(102, 20);
            this.b.TabIndex = 22;
            this.b.Text = "NomorKamar";
            // 
            // c
            // 
            this.c.AutoSize = true;
            this.c.Location = new System.Drawing.Point(20, 172);
            this.c.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(71, 20);
            this.c.TabIndex = 21;
            this.c.Text = "Midweek";
            // 
            // a
            // 
            this.a.AutoSize = true;
            this.a.Location = new System.Drawing.Point(21, 67);
            this.a.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(83, 20);
            this.a.TabIndex = 20;
            this.a.Text = "Username";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(20, 353);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1164, 368);
            this.dataGridView1.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1073, 759);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 36);
            this.button1.TabIndex = 37;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Poin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1233, 817);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.TxtDelete);
            this.Controls.Add(this.TxtUpdate);
            this.Controls.Add(this.TxtSearch);
            this.Controls.Add(this.TxtClear);
            this.Controls.Add(this.TxtSave);
            this.Controls.Add(this.TxtVesper);
            this.Controls.Add(this.TxtSabbath);
            this.Controls.Add(this.TxtPA);
            this.Controls.Add(this.d);
            this.Controls.Add(this.e);
            this.Controls.Add(this.f);
            this.Controls.Add(this.TxtNomorKamar);
            this.Controls.Add(this.TxtMidweek);
            this.Controls.Add(this.TxtNama);
            this.Controls.Add(this.b);
            this.Controls.Add(this.c);
            this.Controls.Add(this.a);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Poin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Poin";
            this.Load += new System.EventHandler(this.Poin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button TxtDelete;
        private System.Windows.Forms.Button TxtUpdate;
        private System.Windows.Forms.Button TxtSearch;
        private System.Windows.Forms.Button TxtClear;
        private System.Windows.Forms.Button TxtSave;
        private System.Windows.Forms.TextBox TxtVesper;
        private System.Windows.Forms.TextBox TxtSabbath;
        private System.Windows.Forms.TextBox TxtPA;
        private System.Windows.Forms.Label d;
        private System.Windows.Forms.Label e;
        private System.Windows.Forms.Label f;
        private System.Windows.Forms.TextBox TxtNomorKamar;
        private System.Windows.Forms.TextBox TxtMidweek;
        private System.Windows.Forms.TextBox TxtNama;
        private System.Windows.Forms.Label b;
        private System.Windows.Forms.Label c;
        private System.Windows.Forms.Label a;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
    }
}