﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace FinalProject
{
    public partial class LoginStudent : Form
    {
        private MySqlConnection koneksi;
        private MySqlDataAdapter adapter;
        private MySqlCommand perintah;

        private DataSet ds = new DataSet();
        private string alamat, query;
        public LoginStudent()
        {
            alamat = "server=localhost; database=project ;username=root; password=;";
            koneksi = new MySqlConnection(alamat);

            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void chB_ShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chB_ShowPass.Checked == true)
            {
                txtPass.UseSystemPasswordChar = false;
            }
            else
            {
                txtPass.UseSystemPasswordChar = true;
            }
        }

        private void btn_HoD_Click(object sender, EventArgs e)
        {
            try
            {
                query = string.Format("SELECT * FROM `mahasiswa` WHERE Username = '{0}'", txtUser.Text);
                ds.Clear();
                koneksi.Open();
                perintah = new MySqlCommand(query, koneksi);
                adapter = new MySqlDataAdapter(perintah);
                perintah.ExecuteNonQuery();
                adapter.Fill(ds);
                koneksi.Close();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow kolom in ds.Tables[0].Rows)
                    {
                        string sandi;
                        sandi = kolom["Password"].ToString();
                        if (txtPass.Text == "Jonathan123")
                        {
                            MainMenu mainMenu = new MainMenu();
                            mainMenu.Show();
                            this.Hide();
                        }
                        else if (txtPass.Text == "Kenrick123")
                        {
                            MainMenu2 mainMenu2 = new MainMenu2();
                            mainMenu2.Show();
                            this.Hide();
                        }
                        else if (sandi == txtPass.Text)
                        {
                            MainMenu3 mainMenu3 = new MainMenu3();
                            mainMenu3.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Anda salah memasukan password");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Anda salah memasukan Username");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void LoginStudent_Load(object sender, EventArgs e)
        {
            txtPass.UseSystemPasswordChar = true;
        }
    }
}
