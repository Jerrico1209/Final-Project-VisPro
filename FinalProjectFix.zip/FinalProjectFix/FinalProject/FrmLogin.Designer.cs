﻿
namespace FinalProject
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.monitors = new System.Windows.Forms.Button();
            this.admin = new System.Windows.Forms.Button();
            this.student = new System.Windows.Forms.Button();
            this.headOfDorm = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Unispace", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(362, 272);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 48);
            this.label2.TabIndex = 15;
            this.label2.Text = "Login as";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(332, 577);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(270, 46);
            this.button1.TabIndex = 14;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // monitors
            // 
            this.monitors.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.monitors.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.monitors.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monitors.ForeColor = System.Drawing.Color.White;
            this.monitors.Location = new System.Drawing.Point(332, 524);
            this.monitors.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.monitors.Name = "monitors";
            this.monitors.Size = new System.Drawing.Size(270, 46);
            this.monitors.TabIndex = 13;
            this.monitors.Text = "Monitors";
            this.monitors.UseVisualStyleBackColor = false;
            this.monitors.Click += new System.EventHandler(this.monitors_Click);
            // 
            // admin
            // 
            this.admin.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.admin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.admin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin.ForeColor = System.Drawing.Color.White;
            this.admin.Location = new System.Drawing.Point(332, 470);
            this.admin.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.admin.Name = "admin";
            this.admin.Size = new System.Drawing.Size(270, 46);
            this.admin.TabIndex = 12;
            this.admin.Text = "Administrator";
            this.admin.UseVisualStyleBackColor = false;
            this.admin.Click += new System.EventHandler(this.admin_Click);
            // 
            // student
            // 
            this.student.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.student.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.student.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.student.ForeColor = System.Drawing.Color.White;
            this.student.Location = new System.Drawing.Point(332, 416);
            this.student.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.student.Name = "student";
            this.student.Size = new System.Drawing.Size(270, 46);
            this.student.TabIndex = 11;
            this.student.Text = "Student";
            this.student.UseVisualStyleBackColor = false;
            this.student.Click += new System.EventHandler(this.student_Click);
            // 
            // headOfDorm
            // 
            this.headOfDorm.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.headOfDorm.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.headOfDorm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headOfDorm.ForeColor = System.Drawing.Color.White;
            this.headOfDorm.Location = new System.Drawing.Point(332, 363);
            this.headOfDorm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.headOfDorm.Name = "headOfDorm";
            this.headOfDorm.Size = new System.Drawing.Size(270, 46);
            this.headOfDorm.TabIndex = 10;
            this.headOfDorm.Text = "Head of dormitory";
            this.headOfDorm.UseVisualStyleBackColor = false;
            this.headOfDorm.Click += new System.EventHandler(this.headOfDorm_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(60, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(823, 232);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(933, 738);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.monitors);
            this.Controls.Add(this.admin);
            this.Controls.Add(this.student);
            this.Controls.Add(this.headOfDorm);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.FrmLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button monitors;
        private System.Windows.Forms.Button admin;
        private System.Windows.Forms.Button student;
        private System.Windows.Forms.Button headOfDorm;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}