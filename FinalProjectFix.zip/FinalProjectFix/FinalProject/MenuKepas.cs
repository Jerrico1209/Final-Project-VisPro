﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    
    public partial class MenuKepas : Form
    {
        private Form activeForm;

        public MenuKepas()
        {
            InitializeComponent();
        }

        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.PanelDesktopPanel.Controls.Add(childForm);
            this.PanelDesktopPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            lblTitle.Text = childForm.Text;

        }

        private void profileButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new InsertDBFrm(), sender);
        }

        private void registKamarButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new UpdateDBFrm(), sender);
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            ReportMahasiswa reportMahasiswa = new ReportMahasiswa();
            reportMahasiswa.Show();
            this.Hide();
        }

        private void MenuKepas_Load(object sender, EventArgs e)
        {

        }

        private void homeButton_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Home3(), sender);
        }

        private void PanelLogo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();

            MessageBox.Show("you've been logged out!");
        }
    }
}
