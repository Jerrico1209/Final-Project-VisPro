﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace FinalProject
{
    public partial class PoinStudent : Form
    {
        private MySqlConnection koneksi;
        private MySqlDataAdapter adapter;
        private MySqlCommand perintah;

        private DataSet ds = new DataSet();
        private string alamat, query;

        public PoinStudent()
        {
            alamat = "server=localhost; database=dbmonitor; username=root; password=;";
            koneksi = new MySqlConnection(alamat);

            InitializeComponent();
        }

        private void textBoxNama_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PoinStudent_Load(object sender, EventArgs e)
        {
            try
            {
                koneksi.Open();
                query = string.Format("Select * from poin Where Username = 'Joshua Tengker'");
                perintah = new MySqlCommand(query, koneksi);
                adapter = new MySqlDataAdapter(perintah);
                perintah.ExecuteNonQuery();
                ds.Clear();
                adapter.Fill(ds);
                koneksi.Close();

                dataGridView1.DataSource = ds.Tables[0];
                dataGridView1.Columns[0].Width = 100;
                dataGridView1.Columns[0].HeaderText = "Username";
                //dataGridView1.Columns[1].Width = 100;
                //dataGridView1.Columns[1].HeaderText = "NomorKamar";
                //dataGridView1.Columns[2].Width = 100;
                //dataGridView1.Columns[2].HeaderText = "Midweek";
                //dataGridView1.Columns[3].Width = 100;
                //dataGridView1.Columns[3].HeaderText = "Vesper";
                //dataGridView1.Columns[4].Width = 100;
                //dataGridView1.Columns[4].HeaderText = "Sabbath";
                //dataGridView1.Columns[5].Width = 100;
                //dataGridView1.Columns[5].HeaderText = "PA";

                textBoxNama.Clear();
                 

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    koneksi.Open();
            //    query = string.Format("Select * from poin where Username = '{0}'", textBoxNama.Text);
            //    perintah = new MySqlCommand(query, koneksi);
            //    adapter = new MySqlDataAdapter(perintah);
            //    perintah.ExecuteNonQuery();
            //    ds.Clear();
            //    adapter.Fill(ds);
            //    koneksi.Close();
            //    if (ds.Tables[0].Rows.Count > 0)
            //    {
            //        foreach (DataRow kolom in ds.Tables[0].Rows)
            //        {
            //            textBoxNama.Text = kolom["Username"].ToString();

            //            //TxtUpdate.Enabled = true;
            //            //TxtDelete.Enabled = true;
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString());
            //}
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            try
            {
                PoinStudent_Load(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
