﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void headOfDorm_Click_1(object sender, EventArgs e)
        {
            HoD HoD = new HoD();
            HoD.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void student_Click(object sender, EventArgs e)
        {
            LoginStudent loginStudent = new LoginStudent();
            loginStudent.Show();
            this.Hide();
        }

        private void admin_Click(object sender, EventArgs e)
        {
            LoginAdmin loginAdmin = new LoginAdmin();
            loginAdmin.Show();
            this.Hide();
        }

        private void monitors_Click(object sender, EventArgs e)
        {
            LoginMonitor loginMonitor = new LoginMonitor();
            loginMonitor.Show();
            this.Hide();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
