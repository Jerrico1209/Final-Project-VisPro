﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{
    public partial class ReportMahasiswa : Form
    {
        public ReportMahasiswa()
        {
            InitializeComponent();
        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            CrystalReport51.SetParameterValue("ParamaterUsername", textBox1.Text);
            crystalReportViewer1.ReportSource = CrystalReport51;
            crystalReportViewer1.Refresh();
            }

        private void ReportMahasiswa_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MenuKepas menuKepas = new MenuKepas();
            menuKepas.Show();
            this.Hide();
        }
    }
}
